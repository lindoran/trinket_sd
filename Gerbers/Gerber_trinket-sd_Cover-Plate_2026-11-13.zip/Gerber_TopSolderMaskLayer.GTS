G04 Layer: TopSolderMaskLayer*
G04 EasyEDA v6.5.61, 2026-11-13 21:20:16*
G04 e98850028ca04823bed5024634da130e,a4fafe20a34a4f4b88dd3d89e6378588,10*
G04 Gerber Generator version 0.2*
G04 Scale: 100 percent, Rotated: No, Reflected: No *
G04 Dimensions in millimeters *
G04 leading zeros omitted , absolute positions ,4 integer and 5 decimal *
%FSLAX45Y45*%
%MOMM*%

%ADD10C,0.0120*%

%LPD*%
M02*
